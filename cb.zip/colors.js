module.exports = {
  primary: `\x1b[94m%s\x1b[0m`,
  author: `\x1b[93m%s\x1b[0m`,
  error: `\x1b[91m%s\x1b[0m`,
  success: `\x1b[96m%s\x1b[0m`
}