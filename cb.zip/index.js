#!/usr/bin/env node

const { program } = require('commander');
const cb = require('./cb');
const figlet = require('figlet');
const colors = require('./colors');

program
.command('cb')
.description('checking all of your coinbase account')
.option('-o, --open <path-file-txt>', 'open your txt file of account')
.action((cmd) => {
  if (cmd.open) {
    figlet('     GaroX CoinbaseX', function(err, data) {
        if (err) {
            console.log('Something went wrong...');
            console.dir(err);
            return;
        }
        console.log(colors.author, data);

        console.log(colors.error, `   ====================================================================================== `);
        console.log(colors.author, `   KontoloDon Foundation `);
        console.log(colors.author, `   @Proxy : ${process.env.PROXY_HOST} `);
        console.log(colors.error, `   ====================================================================================== `);
        
        cb.start(cmd.open);
    });
  }
});

program.parse(process.argv);