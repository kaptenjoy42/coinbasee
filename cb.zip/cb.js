

/* start of file */
require('dotenv').config();
const clc = require("cli-color");
const fs = require('fs');
const colors = require('./colors');
const puppeteer = require("puppeteer-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
const moment = require("moment");
const hotmail = require('./hotmail');
puppeteer.use(StealthPlugin());

const ENABLE_PROXY = process.env.ENABLE_PROXY == 'on' ? true : false;

const check = async (no, total, firstName, lastName, email, password, pathFile) => {
  try {
    console.log(colors.primary, `   [${no}/${total}] Coinbase Checker Service ${moment().format('llll')} - from ${pathFile} Checking ${email}`);
    const emailType = email.split('@')[1];

     ENABLE_PROXY ?
       browser = await puppeteer.launch({
         headless: true,
        args: [`--proxy-server=${process.env.PROXY_HOST || "3.233.129.60:31112"}`],
       }) :
       browser = await puppeteer.launch({
         headless: false
       });

    browser = await puppeteer.launch({
      headless: false,
      args: ['--disable-cookie-encryption']
    })
    
    const [page] = await browser.pages();
    // await page.setViewport({ width: 1366, height: 768 });
    await page.setDefaultNavigationTimeout(0); 

    ENABLE_PROXY ?
      await page.authenticate({
        username: process.env.PROXY_USERNAME,
        password: process.env.PROXY_PASSWORD
      }) : '';

    await page.goto('https://www.coinbase.com/signup', {
      waitUntil: "networkidle2",
    });
    await page.waitForTimeout(10000);

    try {
      await page.waitForSelector("div.sc-fzoLsD.ckSPDD > div.sc-Axmtr.foXfOp > button.sc-AxjAm.kpdUcq")
      const cookieDismis = await page.$("div.sc-fzoLsD.ckSPDD > div.sc-Axmtr.foXfOp > button.sc-AxjAm.kpdUcq")
        cookieDismis.click()
    } catch (e) {
      console.log('something problem!')
    }
    await page.waitForSelector("input[name=firstName]")
    const inputFirstName = await page.$(`input[name="firstName"]`)
    await inputFirstName.type(firstName);
    await page.waitForTimeout(5000);

    const inputLastName = await page.$(`input[name="lastName"]`)
    await inputLastName.type(lastName);
    await page.waitForTimeout(5000);

    const inputEmail = await page.$(`input[name="email"]`)
    console.log(colors.primary, "   Doing email input..");
    await inputEmail.type(email);
    await page.waitForTimeout(1000);

    const inputPassword = await page.$(`input[name="password"]`);
    console.log(colors.primary, "   Doing password input..");
    await inputPassword.type(password);
    await page.waitForTimeout(1000);
  
    const checked = await page.$("div.Flex-l69ttv-0.dMosNC > button");
    checked.click();

    await page.waitForTimeout(25000)
    
    try {
      await page.waitForSelector("div.Flex-l69ttv-0.Signup__SignupFormContainer-sc-1nmo5j5-1.kDVoCa > div > form > button > span")
      const btn = await page.$("div.Flex-l69ttv-0.Signup__SignupFormContainer-sc-1nmo5j5-1.kDVoCa > div > form > button > span")
      btn.click()
    } catch (e) {
      console.log('tidak ketemu')
    }

    try {
      const element = await page.waitForSelector(`div[class="Flex-l69ttv-0 Fields__StyledError-sc-1396sjh-9 iUcENG"]`, { timeout: 3000 });
      const value = await element.evaluate(el => el.textContent);

      switch(value){
        case "Rate Limit exceeded":
        await fs.appendFileSync('results/rechecking.txt', `${email}|${password}\n`)
        console.log(colors.author, `   Please rechecking ${email}! (Bad Proxy!) - Check results/rechecking.txt\r\n`);
        await browser.close();
        return true;
        break;
        case "ReCaptcha used before initialized":
        await fs.appendFileSync('results/rechecking.txt', `${email}|${password}\n`)
        console.log(colors.author, `   Please rechecking ${email}! (Bad Proxy!) - Check results/rechecking.txt\r\n`);
        await browser.close();
        return true;
        break;
        case "ReCaptcha not mounted":
        await fs.appendFileSync('results/rechecking.txt', `${email}|${password}\n`)
        console.log(colors.author, `   Please rechecking ${email}! (Bad Proxy!) - Check results/rechecking.txt\r\n`);
        await browser.close();
        return true;
        break;
        case "Unauthorized":
        await fs.appendFileSync('results/rechecking.txt', `${email}|${password}\n`)
        console.log(colors.author, `   Please rechecking ${email}! (Bad Proxy!) - Check results/rechecking.txt\r\n`);
        await browser.close();
        return true;
        break;
        default:
      }
    } catch (e) {}

    //GPDR
    try {
      await page.waitForSelector(`button[data-element-handle="doneWithIntroButton"]`, { timeout: 3000 })
      await page.click(`button[data-element-handle="doneWithIntroButton"]`);
      // ...
    } catch (e) {}

    //PRIVACY POLICY
    try {
      await page.waitForSelector(`button[data-element-handle="acknowledgePrivacyPolicyButton"]`, { timeout: 3000 })
      await page.click(`button[data-element-handle="acknowledgePrivacyPolicyButton"]`);
      // ...
    } catch (e) {}

    //YES NO
    try {
      await page.waitForSelector("button[data-element-handle=noToEmailButton]", { timeout: 3000 })
      await page.click('button[data-element-handle=noToEmailButton]');
      // ...
    } catch (e) {}

    try {
      const element = await page.waitForSelector(`div.Flex-l69ttv-0.Signup__SignupFormContainer-sc-1nmo5j5-1.kDVoCa > div > form > div.Flex-l69ttv-0.Fields__Errors-sc-1396sjh-8.NaijH > div`, { timeout: 3000 });
      const value = await element.evaluate(el => el.textContent);

      switch(value){
        case "An account already exists with this email address.":
        await fs.appendFileSync('results/live.txt', `${email}|${password}\n`)
        console.log(colors.success, `   Coinbase Account ${email} Status LIVE!\r\n`);
        await browser.close();
        return true;
        break;
        default:
      }
    } catch (e) {}

    const url = await page.url();
    const regexp = url.match(/setup/i);

    if (regexp) {
      await fs.appendFileSync('results/die.txt', `${email}|${password}\n`)
      console.log(colors.error, `   Coinbase Account ${email} Status DIE!\r\n`); 
      await browser.close();
    } else {
      await browser.close();
    }
    
    return true;
  } catch (e) {
    if (e == "TypeError: Cannot read property 'type' of null") {
      await fs.appendFileSync('results/rechecking.txt', `${email}|${password}\n`);
      console.log(colors.author, `   Please rechecking ${email}! (Proxy blocked by ReCaptcha!)`);
    } else if (e == "net::ERR_TUNNEL_CONNECTION_FAILED at https://www.coinbase.com/signup"){
      await fs.appendFileSync('results/rechecking.txt', `${email}|${password}\n`);
      console.log(colors.author, `   Please rechecking ${email}! (Proxy connection failed!)`);         
    } else {
      await errorHandling(e);  
    }
    await browser.close();
  }
}

const asyncForEach = async (array, callback) => {
  for (let index = 0; index < array.length; index++) {
    await callback(array[index], index, array);
  }
}

const errorHandling = async (e) => {
  console.log("   Error Bang ");
  console.log(`   Error : ${e}`);
}

module.exports.start = async (pathFile) => {
  try{
    const content = await fs.readFileSync(pathFile);
    const contentString = await content.toString();
    const accountList = contentString.split('\n');

    await fs.writeFileSync('results/live.txt', '')
    await fs.writeFileSync('results/die.txt', '')

    await asyncForEach(accountList, async (account, index) => {
      const firstName = `${Math.floor(Math.random() * 1000000)}`;
      const lastName = `${Math.floor(Math.random() * 1000000)}`;
      const email = account.split('|')[0];
      const password = `K0NT0LOD04N@$X0XTX654x${Math.floor(Math.random() * 10)}`;

      await check(index+1, accountList.length, firstName, lastName, email, password, pathFile);
    });
  }catch(err){
    console.log(err.message);
  }
}
/* end of file */

